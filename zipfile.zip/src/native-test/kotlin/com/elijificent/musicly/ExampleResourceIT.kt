package com.elijificent.musicly

import io.quarkus.test.junit.QuarkusIntegrationTest

@QuarkusIntegrationTest
class ExampleResourceIT : ExampleResourceTest()
