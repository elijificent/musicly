import System.Random
import Control.Monad
import Data.Text (Text)
import qualified Data.Text.IO as TIO


data Key = C | CSharp | D | DSharp | E | F | FSharp | G | GSharp | A | ASharp | B
  deriving (Show, Eq, Enum, Bounded)

data Octave = Octave Int  -- Example: Octave 4 for middle C
  deriving (Show, Eq)

data MidiNote = MidiNote Int  -- MIDI note number (0-127)
  deriving (Show, Eq)

data Duration = Whole | Half | Quarter | Eighth | Sixteenth
  deriving (Show, Eq, Enum, Bounded)

data Note = Note Key Octave Duration
          | Rest Duration
  deriving (Show, Eq)

data Melody
    = SingleNote Note
    | Chord [Note]  -- Chords are lists of simultaneous notes
    | Sequence [Melody]  -- A sequence of melodies
    | Loop Int Melody  -- Loop a melody a specific number of times
    | InfiniteLoop Melody  -- Loop indefinitely
    | MidiNoteEvent MidiNote Duration  -- MIDI-compatible note event
  deriving (Show, Eq)

-- Generate a random Key
randomKey :: IO Key
randomKey = toEnum <$> randomRIO (fromEnum (minBound :: Key), fromEnum (maxBound :: Key))

-- Generate a random Octave (from 2 to 6 for variety)
randomOctave :: IO Octave
randomOctave = Octave <$> randomRIO (2, 6)

-- Generate a random Duration
randomDuration :: IO Duration
randomDuration = toEnum <$> randomRIO (fromEnum (minBound :: Duration), fromEnum (maxBound :: Duration))

-- Generate a random Note
randomNote :: IO Note
randomNote = do
    key <- randomKey
    octave <- randomOctave
    duration <- randomDuration
    return (Note key octave duration)

-- Generate a random Rest
randomRest :: IO Note
randomRest = Rest <$> randomDuration

-- Generate a random Melody (single note or rest)
randomMelodyElement :: IO Melody
randomMelodyElement = do
    choice <- randomRIO (1, 10 :: Int)
    if choice <= 7  -- 70% chance to be a note
        then SingleNote <$> randomNote
        else SingleNote <$> randomRest  -- 30% chance to be a rest

-- Generate a random Chord
randomChord :: IO Melody
randomChord = do
    numNotes <- randomRIO (2, 4)  -- Chords with 2-4 notes
    notes <- replicateM numNotes randomNote
    return (Chord notes)

-- Generate a random sequence of melodies
randomSequence :: Int -> IO Melody
randomSequence len = do
    elements <- replicateM len randomMelodyElement
    return (Sequence elements)

-- Generate a looping melody
randomLoop :: IO Melody
randomLoop = do
    loopCount <- randomRIO (2, 5)
    subMelody <- randomSequence 3
    return (Loop loopCount subMelody)

-- Generate a random Melody structure
randomMelody :: Int -> IO Melody
randomMelody len = do
    choice <- randomRIO (1, 10 :: Int)
    case choice of
        1 -> randomChord
        2 -> randomLoop
        _ -> randomSequence len  -- Default to a sequence of notes/rests

-- Convert Note to MusicXML format
noteToMusicXML :: Note -> Text
noteToMusicXML (Note key (Octave o) dur) =
    "    <note>\n"
    <> "      <pitch>\n"
    <> "        <step>" <> keyToXML key <> "</step>\n"
    <> "        <octave>" <> pack (show o) <> "</octave>\n"
    <> "      </pitch>\n"
    <> "      <duration>" <> durationToXML dur <> "</duration>\n"
    <> "    </note>\n"
noteToMusicXML (Rest dur) =
    "    <note>\n"
    <> "      <rest/>\n"
    <> "      <duration>" <> durationToXML dur <> "</duration>\n"
    <> "    </note>\n"

-- Convert Melody to MusicXML format
melodyToMusicXML :: Melody -> Text
melodyToMusicXML (SingleNote n) = noteToMusicXML n
melodyToMusicXML (Chord notes) = mconcat (map noteToMusicXML notes)
melodyToMusicXML (Sequence melodies) = mconcat (map melodyToMusicXML melodies)
melodyToMusicXML (Loop times melody) = mconcat (replicate times (melodyToMusicXML melody))

-- Generate full MusicXML document
generateMusicXML :: Melody -> Text
generateMusicXML melody =
    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n"
    <> "<!DOCTYPE score-partwise PUBLIC \"-//Recordare//DTD MusicXML 3.1 Partwise//EN\"\n"
    <> "\"http://www.musicxml.org/dtds/partwise.dtd\">\n"
    <> "<score-partwise version=\"3.1\">\n"
    <> "  <part id=\"P1\">\n"
    <> melodyToMusicXML melody
    <> "  </part>\n"
    <> "</score-partwise>\n"

-- Save MusicXML file for MuseScore
saveMusicXML :: Melody -> IO ()
saveMusicXML melody = do
    let xmlContent = generateMusicXML melody
    TIO.writeFile "melody.xml" xmlContent
    putStrLn "Generated melody.xml for MuseScore!"


-- Example: Generate a random melody of length 8
main :: IO ()
main = do
    melody <- randomMelody 8
    printTab melody          -- Print tablature
    saveMusicXML melody      -- Save as MusicXML
