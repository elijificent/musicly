package com.elijificent.musicly

import at.favre.lib.bytes.BytesValidator.Length
import jakarta.enterprise.context.ApplicationScoped
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.NodeList


enum class Key {
    C, CSHARP, D, DSHARP, E, F, FSHARP, G, GSHARP, A, ASHARP, B
}
data class Bpm(val value: Int)

data class Octave(val value: Int)

data class Midi(val value: Int)

enum class Duration {
    WHOLE, HALF, QUARTER, EIGHTH, SIXTEENTH
}

interface SingleNote

data class Note(
    val key: Key,
    val octave: Octave,
    val duration: Duration
): SingleNote

data class Rest(
    val duration: Duration
): SingleNote

data class Chord(
    val notes: List<Note>
)

interface Melody

data class MelodySequence(
    val melodies: List<Melody>
): Melody

data class LoopX(
    val melody: Melody,
    val times: Int
): Melody

data class MidiNoteEvent(
    val midi: Midi,
    val duration: Duration,
    val velocity: Int
): Melody

data class MidiChordEvent(
    val midi: List<Midi>,
    val duration: Duration,
    val velocity: Int
): Melody

data class MelodyMetadata(
    val melody: Melody,
    val duration: Duration,
    val bpm: Bpm,
    val key: Key,
    val octave: Octave
)

interface MelodyInterface {
    fun generateMelody(key: Key, bpm: Bpm, octave: Octave, duration: Duration, length: Int): MelodyMetadata
    fun generateRandomMelody(key: Key, bpm: Bpm, octave: Octave, duration: Duration, length: Int): MelodyMetadata
    fun generateDerivativeMelody(melody: MelodyMetadata, similarity: Double): MelodyMetadata
}

@ApplicationScoped
class MelodyGenerator: MelodyInterface {
    override fun generateMelody(key: Key, bpm: Bpm, octave: Octave, duration: Duration, length: Int): MelodyMetadata {
        return MelodyMetadata(MelodySequence(listOf()), duration, bpm, key, octave)
    }

    override fun generateRandomMelody(key: Key, bpm: Bpm, octave: Octave, duration: Duration, length: Int): MelodyMetadata {
        return MelodyMetadata(MelodySequence(listOf()), duration, bpm, key, octave)
    }

    override fun generateDerivativeMelody(melody: MelodyMetadata, similarity: Double): MelodyMetadata {
        return MelodyMetadata(MelodySequence(listOf()), melody.duration, melody.bpm, melody.key, melody.octave)
    }
}

//fun parseMusicXML(xmlContent: String): Melody {
//    val doc: Document = DocumentBuilderFactory.newInstance()
//        .newDocumentBuilder()
//        .parse(xmlContent.byteInputStream())
//    doc.documentElement.normalize()
//
//    val noteNodes: NodeList = doc.getElementsByTagName("note")
//    val melodySequence = mutableListOf<Melody>()
//
//    var currentChordNotes = mutableListOf<Note>()
//
//    for (i in 0 until noteNodes.length) {
//        val noteElement = noteNodes.item(i) as Element
//        val isChord = noteElement.getElementsByTagName("chord").length > 0
//        val isRest = noteElement.getElementsByTagName("rest").length > 0
//        val durationValue = noteElement.getElementsByTagName("duration").item(0).textContent.toInt()
//
//        val duration = when (durationValue) {
//            1 -> Duration.SIXTEENTH
//            2 -> Duration.EIGHTH
//            4 -> Duration.QUARTER
//            8 -> Duration.HALF
//            16 -> Duration.WHOLE
//            else -> Duration.QUARTER
//        }
//
//        if (isRest) {
//            melodySequence.add(Rest(duration))
//            continue
//        }
//
//        val pitchElement = noteElement.getElementsByTagName("pitch").item(0) as Element
//        val key = Key.valueOf(pitchElement.getElementsByTagName("step").item(0).textContent)
//        val octave = Octave(pitchElement.getElementsByTagName("octave").item(0).textContent.toInt())
//
//        val note = Note(key, octave, duration)
//
//        if (isChord) {
//            currentChordNotes.add(note)
//        } else {
//            if (currentChordNotes.isNotEmpty()) {
//                melodySequence.add(Chord(currentChordNotes.toList()))
//                currentChordNotes.clear()
//            }
//            melodySequence.add(note)
//        }
//    }
//
//    if (currentChordNotes.isNotEmpty()) {
//        melodySequence.add(Chord(currentChordNotes))
//    }
//
//    return MelodySequence(melodySequence)
//}