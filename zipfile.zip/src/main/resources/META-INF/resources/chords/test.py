from astrapy import DataAPIClient

client = DataAPIClient()
db = client.get_database_by_api_endpoint(
)

print(db.list_collection_names())


import mido
import json

def midi_to_json(midi_file_path, output_json_path):
    """
    Converts a MIDI file to a JSON representation using mido.

    :param midi_file_path: Path to the input .mid file
    :param output_json_path: Desired path for the output .json file
    """
    # Load the MIDI file
    midi = mido.MidiFile(midi_file_path)

    # Prepare a dict to hold structured data
    json_data = {
        "ticks_per_beat": midi.ticks_per_beat,
        "tracks": []
    }

    # Iterate over each track in the MIDI file
    for track_index, track in enumerate(midi.tracks):
        track_data = {
            "name": track.name,
            "messages": []
        }

        # Convert each MIDI message to a dictionary
        for msg in track:
            # mido has a built-in `dict()` method for messages
            track_data["messages"].append(msg.dict())

        json_data["tracks"].append(track_data)

    # Write JSON to disk with indentation
    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2)

    print(f"Converted {midi_file_path} to {output_json_path}")


if __name__ == "__main__":
    # Example usage
    midi_path = "example.mid"
    json_path = "example.json"

    midi_to_json(midi_path, json_path)
