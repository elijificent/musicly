"use client";

import React, { useState } from "react";
import MusicXMLDisplay from "@/app/MusicXMLDisplay";
import { Midi } from "@tonejs/midi";
import * as Tone from "tone";

// Dropdown options
const KEYS = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
const DURATIONS = ["WHOLE", "HALF", "QUARTER", "EIGHTH", "SIXTEENTH"];
const OCTAVES = Array.from({ length: 8 }, (_, i) => i.toString());

// Interface for your melody form config
interface MelodyMetadata {
    key: string;
    bpm: number;
    octave: string;
    duration: string;
    length: number;
}

// Reusable styled button
const Button = ({
                    children,
                    onClick,
                }: {
    children: React.ReactNode;
    onClick?: () => void;
}) => (
    <button
        onClick={onClick}
        className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-700 transition"
    >
        {children}
    </button>
);

// Reusable styled input
const Input = ({
                   type,
                   value,
                   onChange,
                   placeholder,
               }: {
    type: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    placeholder?: string;
}) => (
    <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
);

// Reusable dropdown/select
const Select = ({
                    value,
                    onChange,
                    options,
                }: {
    value: string;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    options: string[];
}) => (
    <select
        value={value}
        onChange={onChange}
        className="border px-3 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
    >
        {options.map((option) => (
            <option key={option} value={option}>
                {option}
            </option>
        ))}
    </select>
);

// Minimal interface for the note events we’ll schedule in Tone.js
interface MidiNoteEvent {
    name: string;
    time: number;
    duration: number;
    velocity: number;
}

// Main page component
const MainPage = () => {
    // Melody config for demonstration or possible usage
    const [melodyConfig, setMelodyConfig] = useState<MelodyMetadata>({
        key: "C",
        bpm: 120,
        octave: "4",
        duration: "QUARTER",
        length: 8,
    });

    // State for MIDI handling
    const [midiFile, setMidiFile] = useState<File | null>(null);
    const [midiData, setMidiData] = useState<null | { tracks: any[] }>(null);

    // State for MusicXML
    const [musicXMLContent, setMusicXMLContent] = useState<string | null>(null);

    // Handle the file input for both MIDI and MusicXML
    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        // Figure out if it's MIDI or XML based on extension
        const isMidi = file.name.toLowerCase().endsWith(".mid");
        const isXml = file.name.toLowerCase().endsWith(".xml");

        if (isMidi) {
            setMidiFile(file);
            const reader = new FileReader();
            reader.onload = async (e) => {
                if (e.target?.result) {
                    // Parse the MIDI data
                    const midi = new Midi(e.target.result as ArrayBuffer);
                    // Tonejs/midi returns an object with tracks, each track has .notes
                    setMidiData(midi);
                }
            };
            reader.readAsArrayBuffer(file);
        } else if (isXml) {
            // Just store as string for the MusicXMLDisplay
            const reader = new FileReader();
            reader.onload = (e) => {
                if (e.target?.result) {
                    setMusicXMLContent(e.target.result as string);
                }
            };
            reader.readAsText(file);
        }
    };

    // Function to schedule notes in Tone.js
    const playMidi = async () => {
        if (!midiData) return;

        // Clear out existing schedules and reset
        Tone.Transport.pause();
        Tone.Transport.cancel(0);
        Tone.Transport.position = 0;

        // Honor BPM from melodyConfig, or from your MIDI
        Tone.Transport.bpm.value = melodyConfig.bpm;

        const synth = new Tone.PolySynth(Tone.Synth).toDestination();

        // Collect notes from tracks and schedule them
        midiData.tracks.forEach((track) => {
            track.notes.forEach((noteEvent: MidiNoteEvent) => {
                Tone.Transport.schedule((time) => {
                    synth.triggerAttackRelease(
                        noteEvent.name,
                        noteEvent.duration, // numeric duration
                        time,
                        noteEvent.velocity
                    );
                }, noteEvent.time);
            });
        });

        // Start the transport
        await Tone.start(); // in some browsers you need an explicit resume
        Tone.Transport.start();
    };

    // Function to stop playback (cancel all events, reset position)
    const stopMidi = () => {
        Tone.Transport.pause();
        Tone.Transport.cancel(0);
        Tone.Transport.position = 0;
    };

    // For demonstration: handle user changes to melody config
    const handleConfigChange = (
        field: keyof MelodyMetadata,
        value: string | number
    ) => {
        setMelodyConfig((prev) => ({ ...prev, [field]: value }));
    };

    return (
        <div className="p-4 space-y-4">
            <h2 className="text-xl font-bold">Melody Editor & MIDI Player</h2>

            {/* Example controls for your MelodyMetadata */}
            <div className="grid grid-cols-2 gap-4">
                <Select
                    value={melodyConfig.key}
                    onChange={(e) => handleConfigChange("key", e.target.value)}
                    options={KEYS}
                />
                <Input
                    type="number"
                    value={melodyConfig.bpm}
                    onChange={(e) => handleConfigChange("bpm", Number(e.target.value))}
                    placeholder="BPM"
                />
                <Select
                    value={melodyConfig.octave}
                    onChange={(e) => handleConfigChange("octave", e.target.value)}
                    options={OCTAVES}
                />
                <Select
                    value={melodyConfig.duration}
                    onChange={(e) => handleConfigChange("duration", e.target.value)}
                    options={DURATIONS}
                />
                <Input
                    type="number"
                    value={melodyConfig.length}
                    onChange={(e) => handleConfigChange("length", Number(e.target.value))}
                    placeholder="Length"
                />
            </div>

            {/* Combined file input for MIDI or XML */}
            <div className="p-4 border rounded-lg bg-blue-200">
                <input
                    type="file"
                    accept=".mid,.midi,.xml"
                    onChange={handleFileUpload}
                    className="p-2 border rounded shadow bg-white"
                />
                <div className="flex space-x-4 mt-4">
                    <Button onClick={playMidi}>Play</Button>
                    <Button onClick={stopMidi}>Stop</Button>
                </div>
            </div>

            {/* Display the MusicXML sheet if loaded */}
            {musicXMLContent && (
                <div className="p-4 border rounded-lg bg-white">
                    <h3 className="text-lg font-semibold">Sheet Music</h3>
                    <MusicXMLDisplay musicXML={musicXMLContent} />
                </div>
            )}
        </div>
    );
};

export default MainPage;
