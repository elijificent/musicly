import { useEffect, useRef, useState } from "react";
import { OpenSheetMusicDisplay } from "opensheetmusicdisplay";

type MusicXMLDisplayProps = {
    musicXML: string; // Accepts MusicXML string (or URL to XML file)
};

const MusicXMLDisplay: React.FC<MusicXMLDisplayProps> = ({ musicXML }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const osmdRef = useRef<OpenSheetMusicDisplay | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!containerRef.current) return;

        osmdRef.current = new OpenSheetMusicDisplay(containerRef.current, {
            autoResize: true,
            drawTitle: true,
            drawComposer: true,
            drawPartNames: true,
        });

        const loadMusicXML = async () => {
            if (osmdRef.current && musicXML) {
                setLoading(true);
                try {
                    await osmdRef.current.load(musicXML);
                    await osmdRef.current.render();
                } catch (error) {
                    console.error("Error loading MusicXML:", error);
                }
                setLoading(false);
            }
        };

        loadMusicXML();
    }, [musicXML]);

    return (
        <div>
            {loading && <p>Loading sheet music...</p>}
            <div ref={containerRef} className="sheet-music-container" />
        </div>
    );
};

export default MusicXMLDisplay;
